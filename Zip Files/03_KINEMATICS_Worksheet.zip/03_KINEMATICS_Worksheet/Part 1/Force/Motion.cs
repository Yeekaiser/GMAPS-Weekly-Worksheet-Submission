// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;

// public class Motion : MonoBehaviour
// {
//     public Vector3 Velocity;

//     void FixedUpdate()
//     {
//         float dt = Time.deltaTime;

//         float dx = /*your code here*/ * dt;
//         float dy = /*your code here*/;
//         float dz = /*your code here*/;

//         transform./*your code here*/(new Vector3(/*your code here*/));
//     }
// }
