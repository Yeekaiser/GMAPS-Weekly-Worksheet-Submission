// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;

// public class FirstLaw : MonoBehaviour
// {
//     public Vector3 force;
//     Rigidbody rb;

//     void Start()
//     {
//         rb = // your code here;
//         rb.// your code here;
//     }

//     void FixedUpdate()
//     {
//         Debug.Log(transform.position);
//     }
// }

