using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SoccerPlayer : MonoBehaviour
{
    //public bool IsCaptain = false;
    //public SoccerPlayer[] OtherPlayers;
    //public float rotationSpeed = 1f;

    //float angle = 0f;

    //private void Start()
    //{
       
    //}

    //float Magnitude(Vector3 vector)
    //{
        
    //}

    //Vector3 Normalise(Vector3 vector)
    //{
        
    //}

    //float Dot(Vector3 vectorA, Vector3 vectorB)
    //{
        
    //}

    //SoccerPlayer FindClosestPlayerDot()
    //{
    //    SoccerPlayer closest = null;

    //    return closest;
    //}

    //void DrawVectors()
    //{
    //    foreach (SoccerPlayer other in OtherPlayers)
    //    {
    //        // Your code here
    //        // ...
    //    }
    //}

    //void Update()
    //{

    //}
}


