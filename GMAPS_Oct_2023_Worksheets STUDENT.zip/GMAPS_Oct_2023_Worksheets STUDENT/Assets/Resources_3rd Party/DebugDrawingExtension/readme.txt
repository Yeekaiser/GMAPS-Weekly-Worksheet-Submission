Product : Debug Drawing Extension Package
Studio : Arkham Interactive
Date : September 17th, 2013
Version : 1.1
Email : support@arkhaminteractive.com

	- To use, simply add DebugExtension.cs to your Unity project
	- Call any of the static functions/overloads in DebugExtension from code to express debug information
	- Use 'Draw' functions anywhere you would use the 'UnityEngine.Gizmo' class (OnDrawGizmos() and OnDrawGizmosSelected())
	- Use 'Debug' functions anywhere you would use the 'UnityEngine.Debug' class (Anywhere else)